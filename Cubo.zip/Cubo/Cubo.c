#include <stdio.h>
#include <conio.h> 

#define WIDTH 20
#define HEIGHT 20

int posX = 0;
int posY = 0;

void drawSquare() {
    int x, y;
    for (y = 0; y < HEIGHT; y++) {
        for (x = 0; x < WIDTH; x++) {
            if (x == posX && y == posY) {
                printf("%c", 254);
            } else {
                printf(" ");
            }
        }
        printf("\n");
    }
}

int main() {
    char input;
    while (1) {
        system("cls"); // Limpia la pantalla (solo funciona en Windows).
        drawSquare();
        input = getch(); 
        switch (input) {
            case 'w':
                posY--;
                break;
            case 'a':
                posX--;
                break;
            case 's':
                posY++;
                break;
            case 'd':
                posX++;
                break;
            case 'q': 
                return 0;
        }
    }
    return 0;
}
